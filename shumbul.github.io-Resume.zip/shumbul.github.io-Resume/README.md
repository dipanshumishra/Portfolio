## Sections 
  a. Profile \
  b. Resume \
  c. Skills \
  d. Certificate \
  e. Contact 
  
## Features to be added
1. Update Images, Resume, Certificates, Skills
2. Enhance and improvise overall look and theme
3. Change font sizes accordingly
4. Add a photo gallery about self
5. Photo gallery of my work (should be presented in a creative style), plus good certificate page
6. Add an option to "expand and view" in the sections of resume.
7. Adding links to other accounts. (Gitlab, Devfolio, Codeforces, Hackerrank, Twitter, Snapchat and Quora)
8. Website's logo
9. Fun section/ Games/ Songs for visitors(Later)
10. No. of visiotrs count on my website(Later)
11. Writeups, thoughts, scribbles(Later)
12. Comment section(Later)
